package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import guiComponents.DateSelector;
import taskPerformance.Accounts;

public class Register extends JFrame {
	
	
	
	
	JLabel student_id, student_password, first_name, middle_name, last_name, section, description, lbl_age, contact_number, eMail, dob;
	JComboBox day,month,year,ages;
	JRadioButton male,female;
	JTextField username, name, middle, last, section_txt, description_txt, contact, email, age;
	JPasswordField password;
	JButton btn1;
	DateSelector date_selector;
	Accounts accounts;
	 
	 public Register() {
		 	accounts = new Accounts();
		 	
		 	setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
		 	setDefaultCloseOperation(EXIT_ON_CLOSE);
		 	getContentPane().setBackground(Color.WHITE);
		 	
		 	guisection1();
		 	guiSection2();
		 	guiSection3();	
	 }
	 
	 private void guisection1(){
		 JPanel section1Flow = new JPanel();
		 section1Flow.setBackground(Color.white);

		 student_id = new JLabel("Student ID");
		 username = new JTextField(10);
		 student_password = new JLabel("Password");
		 password = new JPasswordField(10);
		 first_name = new JLabel("First Name");
		 name = new JTextField(20);
		 middle_name = new JLabel("Middle Name");
		 middle = new JTextField(20);
		 last_name = new JLabel("Last Name");
		 last = new JTextField(20);
		 section = new JLabel("Section");
		 section_txt = new JTextField(20);
		 description = new JLabel("Description (Say something about you):");
		 description_txt = new JTextField(20);
		 contact_number = new JLabel("Contact No.");
		 contact = new JTextField(20);
		 lbl_age = new JLabel("Age");
		 age = new JTextField(20);
		 eMail = new JLabel("Email");
		 email = new JTextField(20);
		 dob = new JLabel("Birthday");
		 
		 
		 JPanel section1 = new JPanel();
		 section1.setBackground(Color.white);
		 section1.setLayout(new BoxLayout(section1, BoxLayout.X_AXIS));
		 
		 JPanel section1Left = new JPanel();
		 section1Left.setBackground(Color.white);
		 section1Left.setLayout(new BoxLayout(section1Left, BoxLayout.Y_AXIS));
		 
		 JPanel section1Right = new JPanel();
		 section1Right.setBackground(Color.white);
		 section1Right.setLayout(new BoxLayout(section1Right, BoxLayout.Y_AXIS));
		 section1Right.setAlignmentX(LEFT_ALIGNMENT);
		 
		
		 section1Left.add(student_id);
		 section1Left.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Left.add(username);
		 section1Left.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Left.add(student_password);
		 section1Left.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Left.add(password);
		 section1Left.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Left.add(first_name);
		 section1Left.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Left.add(name);
		 section1Left.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Left.add(middle_name);
		 section1Left.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Left.add(middle);
		 section1Left.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Left.add(last_name);
		 section1Left.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Left.add(last);
		 section1Left.add(Box.createRigidArea(new Dimension(0,5)));
		 
		 section1Right.add(section);
		 section1Right.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Right.add(section_txt);
		 section1Right.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Right.add(contact_number);
		 section1Right.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Right.add(contact);
		 section1Right.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Right.add(lbl_age);
		 section1Right.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Right.add(age);
		 section1Right.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Right.add(eMail);
		 section1Right.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Right.add(email);
		 section1Right.add(Box.createRigidArea(new Dimension(0,5)));
		 section1Right.add(dob);
		 
		 date_selector = new DateSelector();
		 JPanel gui_date_selector = date_selector.getDateSelector();
		 section1Right.add(gui_date_selector);
		 
		 
		 section1.add(section1Left);
		 section1.add(Box.createRigidArea(new Dimension(50, 0)));
		 section1.add(section1Right);

		 section1Flow.add(section1);
		 
		 add(Box.createRigidArea(new Dimension(0,10)));
		 add(section1Flow);
	 }
	 
	 private void guiSection2() 
	 {
		 JPanel section2Flow = new JPanel();
		 section2Flow.setLayout(new FlowLayout());
		 section2Flow.setBackground(Color.white);
		 
		 JPanel section2Block = new JPanel();
		 section2Block.setLayout(new BoxLayout(section2Block, BoxLayout.Y_AXIS));
		 section2Block.setBackground(Color.white);
		 
		 section2Block.add(description);
		 section2Block.add(Box.createRigidArea(new Dimension(0,5)));
		 section2Block.add(description_txt);
		 section2Block.add(Box.createRigidArea(new Dimension(0,5)));
		 
		 section2Flow.add(section2Block);
		 section2Flow.add(Box.createRigidArea(new Dimension(0, 10)));
		 
		 add(section2Flow);
	 }
	 
	 private void guiSection3() 
	 {
		 JPanel section3 = new JPanel();
		 section3.setLayout(new BoxLayout(section3, BoxLayout.X_AXIS));
		 section3.setBackground(Color.white);
		
		 btn1 = new JButton("Submit");
		 
		 btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				submit();
			}
		});
		 
		 section3.add(btn1);
	
		 
		add(section3);
		add(Box.createRigidArea(new Dimension(0, 40)));
	 }
	 
	 private void submit()
	 {
		 String[] validation = new String[10];
		 
		 String val_birthdate = date_selector.getCompleteDate();
		 String val_email = email.getText();
		 String val_description = description_txt.getText();
		 String val_section = section_txt.getText() ;
		 String val_contact = contact.getText();
		 String val_age = age.getText();
		 String val_first_name = name.getText();
		 String val_middle_name = middle.getText();
		 String val_last_name = last.getText();
		 String val_password = password.getText();
		 String val_username = username.getText();
		 
		 System.out.println(val_email);
		 
		 if (val_birthdate.isEmpty()) {
			 eMail.setForeground(Color.red);
			 validation[9] = "Date";
		 } else {
			 eMail.setForeground(Color.black);
		 }
		 
		 if (val_email.isEmpty()) {
			 
			 System.out.println("here 3");
			 eMail.setForeground(Color.red);
			 validation[8] = "Email";
		 } else {
			 eMail.setForeground(Color.black);
		 }
		 
		 if (val_description.isEmpty()) {
			 System.out.println("here 4");
			 description.setForeground(Color.red);
			 validation[7] = "About you";
		 } else {
			 description.setForeground(Color.black);
		 }
	 	
		 if (val_section.isEmpty()) {
			 section.setForeground(Color.red);
			 validation[6] = "Section";
		 } else {
			 section.setForeground(Color.black);
		 }
		 
		 if (val_contact.isEmpty()) {
			 contact_number.setForeground(Color.red);
			 validation[5] = "Contact Number";
		 } else {
			 contact_number.setForeground(Color.black);
		 }
		 if(val_age.isEmpty()) {
			 lbl_age.setForeground(Color.red);
		 }
		 else {
			 lbl_age.setForeground(Color.black);
		 }
		 
		 if (val_last_name.isEmpty()) {
			 last_name.setForeground(Color.red);
			 validation[4] = "Last Name";
		 } else {
			 last_name.setForeground(Color.black);
		 }

		 if (val_middle_name.isEmpty()) {
			 middle_name.setForeground(Color.red);
			 validation[3] = "Middle Name";
		 } else {
			 middle_name.setForeground(Color.black);
		 }
		 
		 if (val_first_name.isEmpty()) {
			 first_name.setForeground(Color.red);
			 validation[2] = "Name";
		 } else {
			 first_name.setForeground(Color.black);
		 }
		 
		 if (val_password.isEmpty()) {
			 student_password.setForeground(Color.red);
			 validation[1] = "Password";
		 } else {
			 student_password.setForeground(Color.black);
		 }
		 
		 if (val_username.isEmpty()) {
			 student_id.setForeground(Color.red);
			 validation[0] = "Username";
		 } else {
			 student_id.setForeground(Color.black);
		 }
		 
		 validation = Arrays.stream(validation)
                 .filter(s -> (s != null && s.length() > 0))
                 .toArray(String[]::new);  
		 
		 if (validation.length > 0) {
			 
			 JFrame f1 = new JFrame();
			
			JOptionPane.showMessageDialog(f1, "Please fill up the following " + String.join(",", validation));
			 
			 return;
		 } else {
			accounts.create(val_username, val_password, val_first_name, val_middle_name, val_last_name, val_contact, val_section, val_description, val_email, val_birthdate);;
		 
			JFrame f1 = new JFrame();
			Login s = new Login();
				
			JOptionPane.showMessageDialog(f1, "Registration Complete");
			
			dispose();
			
			s.setBounds(400, 200, 350, 300);
			s.setVisible(true);
		 }
	 }
}
