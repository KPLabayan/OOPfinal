package gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

import javax.swing.JTextField;

import taskPerformance.Accounts;

public class Login extends JFrame {
	
	JLabel label_username, label_password, third, msg;
	JTextField username;
	JPasswordField password;
	JPanel firstP;
	
	JFrame secondFrame;
	
	JButton button_login;
	JButton button_register;
	Accounts accounts;
	
	public Login() {
		accounts = new Accounts();
		
		setTitle("WELCOME");
		setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	 	getContentPane().setBackground(Color.WHITE);
	 	
	 	guiSection1();
	 	guiSection2();
	 	guiSection3();
	}

	private void guiSection1()
	{
		JPanel section1 = new JPanel();
		section1.setLayout(new BoxLayout(section1, BoxLayout.X_AXIS));
		section1.setBackground(Color.white);
		
	 	var icon =  new ImageIcon("src//main//image//sti-logo.png");
	 	Image image = icon.getImage(); // transform it 
	 	Image newimg = image.getScaledInstance(100, 50,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
	 	icon = new ImageIcon(newimg);

	 	JLabel sti_logo = new JLabel(icon);
	 	sti_logo.setAlignmentX(Component.CENTER_ALIGNMENT);
	 	
	 	section1.add(Box.createRigidArea(new Dimension(0,70)));
	 	section1.add(sti_logo);
	 	section1.add(Box.createRigidArea(new Dimension(0,80)));

		add(section1);
	}
	
	private void guiSection2()
	{
		JPanel section2Flow = new JPanel();
		section2Flow.setBackground(Color.white);
		
		JPanel section2 = new JPanel();
		section2.setLayout(new BoxLayout(section2, BoxLayout.Y_AXIS));
		section2.setBackground(Color.white);
		
		label_username = new JLabel("Student ID");
		label_username.setAlignmentX(Component.CENTER_ALIGNMENT);
		username = new JTextField(20);
		label_password = new JLabel("Password");
		label_password.setAlignmentX(Component.CENTER_ALIGNMENT);
		password = new JPasswordField(20);
	
		
		section2.add(label_username);
		section2.add(Box.createRigidArea(new Dimension(0,3)));
		section2.add(username);
		section2.add(Box.createRigidArea(new Dimension(0,3)));
		section2.add(label_password);
		section2.add(Box.createRigidArea(new Dimension(0,3)));
		section2.add(password);
		
		section2Flow.add(section2);
		section2Flow.add(Box.createRigidArea(new Dimension(10, 0)));
		
		add(section2Flow);
	}
	
	private void guiSection3()
	{
		JPanel section3Flow = new JPanel();
		section3Flow.setBackground(Color.white);
		msg = new JLabel("");
		msg.setForeground(Color.red);
		
		
		JPanel section3 = new JPanel();
		section3.setLayout(new BoxLayout(section3, BoxLayout.X_AXIS));
		section3.setBackground(Color.white);
		
		button_login = new JButton("Log in");
		button_register = new JButton("Register");
		
		
		section3.add(button_login);
	 	section3.add(Box.createRigidArea(new Dimension(20,0)));

		section3.add(button_register);
	 	section3.add(Box.createRigidArea(new Dimension(20,60)));
	 	
		button_login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent a) {
				boolean match = false;
				String name, pass;
				name = username.getText().toString().trim();
				pass = password.getText().toString().trim();
				
				if (name.isEmpty()) {
					label_username.setForeground(Color.red);
				} else {
					label_username.setForeground(Color.black);
				}
				
				if (pass.isEmpty()) {
					label_password.setForeground(Color.red);
				} else {
					label_password.setForeground(Color.black);
				}
				
				
				if (name.isEmpty() || pass.isEmpty()) {
					return;
				}
				
				if (accounts.login(name, pass)) {
					Dashboard ds = new Dashboard();
					ds.loadStudentInfo(accounts.getCurrentAccount());
					
					dispose();
					
					ds.setVisible(true);
					
			
					
				} else {
					JFrame f1 = new JFrame();
					JOptionPane.showMessageDialog(f1, "Invalid Credentials");
				}
			}
		});
		
		button_register.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
					dispose();
					Register s = new Register();
					s.setVisible(true);
					s.setBounds(400, 200, 700, 500);
				
			}
		});
 		
		section3Flow.add(msg);
		section3Flow.add(section3);
		add(section3Flow);
		
	}
}
