package gui;

import java.awt.Color;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Dashboard extends JFrame {
	JLabel name,section,bday,description,subj,email,cn,age,dName;
	 JTextField  dSection, dBday, dDescription;
	 
	 
	 
	 public Dashboard() {
		 setLayout(null);
		 setDefaultCloseOperation(EXIT_ON_CLOSE);
		 setBackground(Color.WHITE);
		 setLocationRelativeTo(null);
		 setSize(400, 400);
		 
		 name = new JLabel("Name:");
		 section = new JLabel("Section:");
		 bday = new JLabel("Birthday:");
		 description = new JLabel("About me: ");
		 subj = new JLabel("Subjects");
		 dName = new JLabel("");
		 email = new JLabel("Email:");
		 cn = new JLabel("Contact No.:");
		 age = new JLabel("Age:");
		 
		 name.setBounds(30,60,200,25);
		 section.setBounds(30,100,200,25);
		 bday.setBounds(30,140,200,25);
		 email.setBounds(30,180,200,25);
		 cn.setBounds(30,220,200,25);
		 age.setBounds(30,260,200,25);
		 description.setBounds(30,300,200,25);
		 
		 subj.setBounds(400,60,200,25);
		 
		 
		 dName.setBounds(100,60,165,25);
		 
		 add(name);
		 add(section);
		 add(bday);
		 add(description);
		 add(subj);
		 add(email);
		 add(cn);
		 add(age);
	 }
	 
	 public void loadStudentInfo(Map<String, String> account) {
		 String full_name = account.get("first_name") + " " + account.get("middle_name") + " " + account.get("last_name");
		 name.setText(name.getText() + " " + full_name);
		 section.setText(section.getText() + " " + account.get("section"));
		 bday.setText(bday.getText() + " " + account.get("birthdate"));
		 description.setText(description.getText() + " " + account.get("description"));
		 email.setText(email.getText() + " " + account.get("email"));
		 cn.setText(cn.getText() + " " + account.get("contact_number"));
	 }
}
