package guiComponents;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JComboBox;
import javax.swing.JPanel;

public class DateSelector {
	List<Map<String, String>> Months;
	JComboBox<?> gui_years, gui_months, gui_dates;
	
	private static final int MIN_YEAR = 1996;
	private static final int MAX_YEAR = 2023;
	
	private static int selected_year_index = 0;
	private static int selected_month_index = 0;
	private static int selected_date_index = 0;

	public DateSelector() {
	 	
		Months = new ArrayList<>();
		
		// Initialize months
		setJanuary();
		setFebruary();
		setMarch();
		setApril();
		setMay();
		setJune();
		setJuly();
		setAugust();
		setSeptember();
		setOctober();
		setNovember();
		setDecember();
	}
	
	private void setJanuary() {
		setMonth(0, "Jan", "31");
	}
	
	private void setFebruary() {
		setMonth(1, "Feb", "28");
	}
	
	private void setMarch() {
		setMonth(2, "Mar", "31");
	}
	
	private void setApril() {
		setMonth(3, "Apr", "30");
	}
	
	private void setMay() {
		setMonth(4, "May", "31");
	}
	
	private void setJune() {
		setMonth(5, "Jun", "30");
	}
	
	private void setJuly() {
		setMonth(6, "Jul", "31");
	}
	
	private void setAugust() {
		setMonth(7, "Aug", "31");
	}
	
	private void setSeptember() {
		setMonth(8, "Sep", "30");
	}
	
	private void setOctober() {
		setMonth(9, "Oct", "31");
	}
	
	private void setNovember() {
		setMonth(10, "Nov", "30");
	}
	
	private void setDecember() {
		setMonth(11, "Dec", "31");
	}
	
	private void setMonth(Integer index, String name, String days) 
	{
		Map<String, String> month = new HashMap<String, String>();
		
		month.put("name", name);
		month.put("days", days);
		
		Months.add(index, month);
	}
	
	public List<Map<String, String>> getCalendar() 
	{
		return Months;
	}
	
	public JPanel getDateSelector() 
	{
		JPanel dspanel = new JPanel();
		dspanel.setBackground(Color.white);
		dspanel.setBounds(0, 0, 257, 30);
		
		Integer[] years = getYears();
		String[] months = getMonths();
		Integer[] dates = getDates();
		
		gui_years = new JComboBox<Integer>(years);
		gui_months = new JComboBox<String>(months);
		gui_dates = new JComboBox<Integer>(dates);
		
		addMonthChangeActionListener(gui_months, (JComboBox<Integer>) gui_dates);
		
		dspanel.add(gui_months);
		dspanel.add(gui_dates);
		dspanel.add(gui_years);
		
		return dspanel;
	}
	
	private void addMonthChangeActionListener(JComboBox<?> gui_months, JComboBox<Integer> gui_dates)
	{	
		gui_months.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				selected_month_index = gui_months.getSelectedIndex();
				selected_date_index = 0;
				
				Integer[] dates = getDates();
				gui_dates.removeAllItems();
				
				for(Integer date:dates){
					gui_dates.addItem(date);
			    }
				
			}
		});
	}
	
	private Integer[] getYears()
	{
		Integer[] years = new Integer[MAX_YEAR - MIN_YEAR];
		int years_index = 0;
		
		for (int i = MIN_YEAR; i < MAX_YEAR; i++) {
			years[years_index] = i;
			years_index++;
		}
		
		return years;
	}
	
	private String[] getMonths() {
		
		String[] months = new String[Months.size()];
		
		for (int i = 0; i < Months.size(); i++) {
			months[i] = Months.get(i).get("name");
		}
		
		return months;
	}
	
    private Integer[] getDates() {
    	Map<String, String> selected_month = Months.get(selected_month_index);
    	
    	System.out.println(selected_month.get("days"));
    	int days_count = Integer.parseInt(selected_month.get("days"));
    	
    	Integer[] dates = new Integer[days_count];
    	
    	for (int i = 0; i < days_count; i++) {
    		dates[i] = i + 1;
		}
    	
    	return dates;
	}
	
	public String getCompleteDate()
	{	
		return gui_months.getSelectedItem().toString() + " " + gui_dates.getSelectedItem().toString() + " " + gui_years.getSelectedItem().toString();
	}
	
}
