package taskPerformance;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Accounts {

	
	List<Map<String, String>> accounts;
	int account_count = 0;
	Map<String, String> current_account;
	
	public Accounts()
	{
		load();
	}
	
	public void load()
	{
		try {
			account_count = 0;
			accounts = new ArrayList<>();
			BufferedReader reader;
			
			reader = new BufferedReader(new FileReader("accounts"));
			String line = reader.readLine();
			
			while (line != null) {
		
				String data_arr[] = line.split(",");

				
				Map<String, String> account = new HashMap<String, String>();
			
				account.put("username", data_arr[0]);
				account.put("password", data_arr[1]);
				account.put("first_name", data_arr[2]);
				account.put("middle_name", data_arr[3]);
				account.put("last_name", data_arr[4]);
				account.put("section", data_arr[5]);
				account.put("contact_number", data_arr[6]);
				account.put("description", data_arr[7]);
				account.put("email", data_arr[8]);
				account.put("birthdate", data_arr[9]);

				accounts.add(account);
				
				// read next line
				line = reader.readLine();
				
				account_count++;
			}
			
			reader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Map<String, String> getCurrentAccount()
	{
		return current_account;
	}
	
	public boolean login(String username, String password)
	{
		for (int i=0; i< account_count;i++) {
			System.out.println(accounts.get(i).get("username"));
			System.out.println(accounts.get(i).get("password"));
			if (accounts.get(i).get("username").equals(username) && accounts.get(i).get("password").equals(password)) {
				current_account = accounts.get(i);
				
				return true;
			}
		}
		
		return false;
	}
	
	public void create(
			String username, 
			String password, 
			String first_name, 
			String middle_name, 
			String last_name,
			String contact_number,
			String section,
			String description,
			String email,
			String birthdate
	)
	{
		String data = username + "," + password + "," + first_name + "," + middle_name + "," + last_name 
				+ "," + contact_number 
				+ "," +  section
				+ "," + description + "," + email + "," + birthdate;
		
		try {
			File fout = new File("accounts");
			FileOutputStream fos = new FileOutputStream(fout);
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
			
			for (int i = 0; i < account_count; i++) {
				bw.write(
					accounts.get(i).get("username") 
					+ "," + accounts.get(i).get("password") 
					+ "," + accounts.get(i).get("first_name")
					+ "," + accounts.get(i).get("middle_name")
					+ "," + accounts.get(i).get("last_name")
					+ "," + accounts.get(i).get("contact_number")
					+ "," + accounts.get(i).get("section")
					+ "," + accounts.get(i).get("description")
					+ "," + accounts.get(i).get("email")
					+ "," + accounts.get(i).get("birthdate")
				);
				bw.newLine();
			}
			
			bw.write(data);
			bw.close();
			
		} catch (IOException e) {
	
			e.printStackTrace();
		}
	}
}
