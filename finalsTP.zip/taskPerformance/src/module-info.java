
module taskPerformance {
	requires java.desktop;
}