package main;


import java.io.IOException;
import javax.swing.JFrame;
import gui.Login;

class StudentInformation extends JFrame {
	
	//main method
	public static void main(String[] args) throws IOException {

		Login s = new Login();
		s.setBounds(400, 200, 350, 300);
		s.setVisible(true);	
	}
}