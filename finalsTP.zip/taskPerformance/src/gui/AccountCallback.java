package gui;

public interface AccountCallback {
	void onDeleteSuccess();
	void onDeleteFailed();
	void onAccountNotFound(String message);
}
