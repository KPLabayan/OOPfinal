package gui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import taskPerformance.Accounts;
import gui.AccountCallback;
public class Delete extends JFrame {
	JButton deleteAcc;
	JLabel user,pass;
	JTextField userID;
	JPasswordField userPass;
	
	Accounts account;
	
	public Delete() {
		account = new Accounts();
		setLayout(null);
		 setDefaultCloseOperation(EXIT_ON_CLOSE);
		 getContentPane().setBackground(Color.WHITE);
		 setSize(200, 200);
		 
		 user = new JLabel("User ID");
		 pass = new JLabel("Password");
		 user.setBounds(30,30,60,25);
		 pass.setBounds(30,60,60,25);
		 
		 add(user);
		 add(pass);
		 
		 userID = new JTextField(20);
		 userPass = new JPasswordField(20);
		 
		 userID.setBounds(100,30,200,25);
		 userPass.setBounds(100,60,200,25);
		 
		 add(userID);
		 add(userPass);
		 
		 deleteAcc = new JButton("Delete");
		 deleteAcc.setBounds(230,120,80,25);
		 add(deleteAcc);
		 
		 deleteAcc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String user = userID.getText();
				String pass = userPass.getText();
				
				try {
					Accounts.deleteAccount(user, pass, new AccountCallback() {
						public void onDeleteSuccess() {
							JOptionPane.showMessageDialog(null,"Delete Success", "Account Deletion", JOptionPane.INFORMATION_MESSAGE);
									Login s = new Login();
									dispose();
									s.setVisible(true);
									s.setBounds(400, 200, 350, 300);
							
						}

						@Override
						public void onDeleteFailed() {
							JOptionPane.showMessageDialog(null, "Delete failed. User not found","Account Deletion", JOptionPane.INFORMATION_MESSAGE);
							Login s = new Login();
							dispose();
							s.setVisible(true);
							s.setBounds(400, 200, 350, 300);
							
						}

						@Override
						public void onAccountNotFound(String message) {
							JOptionPane.showMessageDialog(null, message, "Account Deletion", JOptionPane.INFORMATION_MESSAGE);
							Login s = new Login();
							dispose();
							s.setVisible(true);
							s.setBounds(400, 200, 350, 300);
							
						}
						

					});
				} catch(Exception ea) {
					
					ea.printStackTrace();
					JOptionPane.showMessageDialog(null,"Error Deleting this user", "Account Deletion", JOptionPane.INFORMATION_MESSAGE);
					
				}
				
					
				
				
			}
			 
		 });
		 
	}

}
